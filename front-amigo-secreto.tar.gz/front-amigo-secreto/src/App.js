import Select from "react-tailwindcss-select";
import { useState, useEffect } from "react";
import axios from "axios";

function fixPeopleListGetResponse({ people }) {
  // { "was_picked": true, "did_pick": true, "label": "Alan" },
  let x = people.map((person) => ({
    value: person.label,
    label: person.label,
    disabled: person.did_pick,
  }));
  console.log("ASDJASNDKASNDKJASNDASD");
  return x;
}

const PersonSelector = ({ person, onChange }) => {
  const [people, setPeople] = useState([]);

  useEffect(() => {
    async function getPeople() {
      let response = await axios.get("http://127.0.0.1:3000", {});
      let people = fixPeopleListGetResponse(response.data);
      // TODO: comentar isso em prod
      console.log(people);
      setPeople(people);
    }
    getPeople();
  }, []);

  let CssOverride = {
    listDisabledItem:
      "font-bold px-2 py-2 cursor-not-allowed truncate text-opacity- text-slate-300 select-none",
  };

  return (
    <Select
      classNames={CssOverride}
      value={person}
      onChange={onChange}
      options={people}
      placeholder={"Quem é você?"}
      searchInputPlaceholder={"Pesquisar..."}
      noOptionsMessage={"Nome não encontrado"}
      isClearable
      isSearchable
    />
  );
};

const DraftButton = ({ personWhosDrafting, onDraw }) => {
  let isDisabled = personWhosDrafting === null;

  return (
    <div className="--centralized-div">
      <button
        onClick={onDraw}
        className="--confirmation-button"
        disabled={isDisabled}
      >
        Sortear
      </button>
    </div>
  );
};

const App = () => {
  const [person, setPerson] = useState(null);

  const cleanScreen = () => {
    const myNode = document.getElementById("root");
    while (myNode.lastElementChild) {
      myNode.removeChild(myNode.lastElementChild);
    }
  };

  const itWorkedFn = (x) => {
    console.log(x);
    let name = x.data.chosen_one;

    alert(`Você sorteou ${name}!\nAnotaí.`);
    alert(`Pegue um presente bem bacana!`);
    alert(`Foi ${name}, esqueça não viu?`);
    cleanScreen();
  };
  const itFailedFn = () => {
    alert(`Algum erro aconteceu :( falar com Alan.`);
    cleanScreen();
  };

  async function onDraw() {
    let headers = { headers: { my_label: person.label } };
    axios
      .post("http://127.0.0.1:3000", {}, headers)
      .then(itWorkedFn, itFailedFn);
  }

  return (
    <div className="--root-div">
      <div className="--main-page-div">
        <header className="--header">
          Bem vindo ao sorteio do Amigo Secreto!
        </header>
        <PersonSelector person={person} onChange={setPerson} />
        <DraftButton personWhosDrafting={person} onDraw={onDraw} />
      </div>
    </div>
  );
};

export default App;
