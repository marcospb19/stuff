use std::io;

use astra::{ConnectionInfo, Request, Response, ResponseBuilder, Server};
use fs_err as fs;
use http::Method;
use rand::{prelude::SliceRandom, rngs::SmallRng, SeedableRng};
use serde::{Deserialize, Serialize};

fn main() {
    Server::bind("127.0.0.1:3000").serve(router).unwrap();
}

fn router(request: Request, _info: ConnectionInfo) -> Response {
    let function = match request.method() {
        &Method::GET => get,
        &Method::POST => post,
        &Method::OPTIONS => return into_response("").unwrap(),
        method => {
            panic!("erro no method: {method:?}")
        }
    };

    function(request)
}

#[derive(Serialize, Deserialize, Clone, Debug)]
struct GetResponse {
    people: Vec<Person>,
}

fn get(_request: Request) -> Response {
    let people = load_people_from_file();
    let response = GetResponse { people };
    into_response(response).unwrap()
}

#[derive(Serialize, Deserialize, Clone, Debug)]
struct PostResponse {
    chosen_one: String,
}

fn post(request: Request) -> Response {
    let mut people = load_people_from_file();
    let mut people_lables = people.iter().map(|x| &x.label).collect::<Vec<_>>();

    let person_who_picking_label = request.headers()["my_label"].to_str().unwrap();

    let seed = std::env::args()
        .nth(1)
        .expect("Failed to get argv[1], expected seed number [0-256]")
        .parse::<u8>()
        .expect("failed to parse argv[1]");

    let mut rng = SmallRng::from_seed([seed as u8; 32]);
    people_lables.shuffle(&mut rng);

    dbg!(&people_lables);

    let label_iter = people_lables.iter();
    let next_label_iter = people_lables.iter().cycle().skip(1);

    let mut label_window_iter = label_iter.zip(next_label_iter);

    let drafted_person = label_window_iter
        .find(|(current, _)| current == &&person_who_picking_label)
        .unwrap()
        .1
        .to_string();

    let drafted_person_reference = people
        .iter_mut()
        .find(|x| *x.label == *drafted_person)
        .unwrap();
    drafted_person_reference.was_picked = true;
    let person_who_picked_reference = people
        .iter_mut()
        .find(|x| *x.label == *person_who_picking_label)
        .unwrap();
    person_who_picked_reference.did_pick = true;

    dump_people_to_file(people).unwrap();

    let response = PostResponse {
        chosen_one: drafted_person.to_string(),
    };
    into_response(response).unwrap()
}

fn into_response<T: Serialize>(x: T) -> Result<Response, serde_json::Error> {
    serde_json::to_string(&x).map(|x| {
        ResponseBuilder::new()
            .header("Access-Control-Allow-Headers", "*")
            .header("Access-Control-Allow-Origin", "*")
            .body(x.into())
            .unwrap()
    })
}

trait IntoResponse {
    fn into_response(self) -> Response;
}

#[derive(Serialize, Deserialize, Clone, Debug)]
struct Person {
    label: String,
    was_picked: bool,
    did_pick: bool,
}

fn load_people_from_file() -> Vec<Person> {
    let string = fs::read_to_string("file.json").unwrap();
    let mut people = serde_json::from_str::<Vec<Person>>(&string).unwrap();
    people.sort_by(|a, b| a.label.cmp(&b.label));
    people
}

fn dump_people_to_file(people: Vec<Person>) -> io::Result<()> {
    let people = serde_json::to_string_pretty(&people).unwrap();
    fs::write("file.json", people)
}
